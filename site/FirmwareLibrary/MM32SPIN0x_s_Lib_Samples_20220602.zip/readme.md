# LibSamples_MM32SPIN06

## Introduction

LibSamples_MM32SPIN06 is to provide the software package for developing MindMotion MM32SPIN06 MCU. The software package includes the device's header file, linker file, startup code, peripherals drivers and examples projects.

## User guide

### ToolChains

- Keil MDK for Arm, v5.34.0.0, with MindMotion.MM32SPIN06_DFP.pack.
- IAR IDE for Arm, v8.30.1, with zip file MM32_IAR_EWARM_pack.zip.

### Hardware board

- MB-025(MM32SPIN06PS)

### Source files

| directory                                | description              |
| ---------------------------------------- | ------------------------ |
| `\Device\MM32SPIN06xx_s`                      | CMSIS files.    |
| `\Device\MM32SPIN06xx_s\HAL_Lib`              | Drivers.                 |
| `\Samples\LibSamples\<MODULE>\<Example>` | Driver example projects. |

### Example projects

 - ADC
     - ADC_Awdg
     - ADC_DMA_Interrupt
     - ADC_DMA_polling
     - ADC_Interrupt
     - ADC_Polling
 - BKP
     - BKP_Tamper
 - CAN
     - CAN_Polling
     - CAN_RX_Interrupt
     - CAN_TX
 - COMP
     - COMP_Polling
 - CRC
     - CRC_BasicExample
 - DIV
     - DIV_Operation
 - DMA
     - DMA_SRAMtoSRAM
 - EXTI
     - EXTI_Key
 - FLASH
     - FLASH_Program
     - FLASH_SetReadProtect
     - FLASH_SIM_EEPROM
 - GPIO
     - GPIO_Key
     - GPIO_Toggle
 - I2C
     - I2C_EEPROM_DMA_Master_Interrupt
     - I2C_EEPROM_DMA_polling
     - I2C_EEPROM_Master_Interrupt
     - I2C_EEPROM_Polling
     - I2C_GPIO_SIM_EEPROM
 - IWDG
     - IWDG_Reset
 - PWR
     - PWR_PVD_Interruput
     - PWR_PVD_Polling
     - PWR_Sleep_WFI_Wakeup
     - PWR_Standby_IWDG_Wakeup
     - PWR_Stop_EXTI_GPIO_Wakeup
 - RCC
     - RCC_MCO
 - SPI
     - SPI_FLASH_DMA_Polling
     - SPI_FLASH_Interrupt
     - SPI_FLASH_Polling
     - SPI_FLASH_SoftNSS
     - SPI_GPIO_SIM_ExSpiFlash
 - SYSTICK
     - SYSTICK_System1msDelay
 - TIM
     - TIM1_6Steps
     - TIM1_BasicExample
     - TIM1_CC1_Interrupt
     - TIM1_Interrupt
     - TIM1_Monopulse
     - TIM2_BasicExample
     - TIM3_PWM_Input
     - TIM3_PWM_Output
 - UART
     - UART_Polling
     - UART_Print_Polling
 - WWDG
     - WWDG_Reset

## Known issues

- On-board MM32Link UART  issue
    On-board MM32Link UART output data is with abnormal sequence.

