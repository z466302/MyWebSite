# FLASH_Program

## Introduction

This demo shows the  MCU's flash feature.

If the programming is successful, make the LED2 blinks , otherwise make the LED1 blinks.

## Run

The LED2 blinks, which means that the flash programming is successful.
