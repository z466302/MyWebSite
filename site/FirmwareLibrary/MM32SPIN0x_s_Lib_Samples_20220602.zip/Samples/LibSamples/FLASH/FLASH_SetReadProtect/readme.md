# FLASH_SetReadProtect

## Introduction

This demo shows the  MCU's flash read protect feature.

If the programming is successful, make the LED2 blinks , otherwise make the LED1 blinks.

## Note

After using this use case, please erase the chip flash before downloading other demo.

## Run

The LED2 blinks, which means that the flash programming is successful.
