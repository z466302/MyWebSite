# DIV_Operation

## Introduction

This demo shows the MCU's  hardware divider feature.
Verify the featrue of the hardware divider by comparing the results calculated by the hardware divider and the software divider.

## Run

1. Run the program and print the data through serial port as follows：

DIV_Operation example test:
HWDIV:152709948
SWDIV:152709948
HWDIV:53289414
SWDIV:53289414
HWDIV:39880913
SWDIV:39880913
...
HWDIV:2268845
SWDIV:2268845
DIV_Operation example test over.