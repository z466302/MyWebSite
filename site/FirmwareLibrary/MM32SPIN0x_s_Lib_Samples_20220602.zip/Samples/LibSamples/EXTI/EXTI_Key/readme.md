# EXTI_KEY

## Introduction

 This demo shows the  EXTI's external interruption.

Completed an external interrupt feature triggered by four keys.

## Run

When the  K1~K4 are pressed, the LED1~LED4 on or off.
