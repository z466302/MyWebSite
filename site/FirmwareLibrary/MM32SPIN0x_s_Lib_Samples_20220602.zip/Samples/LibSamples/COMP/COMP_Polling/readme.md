# COMP_Polling

## Introduction

This demo shows the  COMP's Polling featue.

The PA0 pin is used as inverting input. 
The PA2 pin is used as non-inverting input.  

Compare the voltage value of the non-inverting input(PA2) and the inverting input(PA0), and output the comparison result by the UART.

## Run

1. Connect PA2 to GND and connect PA0 to VCC, the non-inverting input is smaller than the inverting input. The serial port with baud rate of 115200 prints out 'the comparator result is: 0'.
2. Connect PA2 to VCC and connect PA0 to GND, the non-inverting input is greater than the inverting input. The serial port with baud rate of 115200 prints out 'the comparator result is: 1'.
