# IWDG_Reset

## Introduction

This demo shows the IWDG's reset feature.
After ten feed dog operations, waiting for the MCU reset, and the MCU reset, print the data through the serial port again.

## Run
If the system has resumed from IWDG reset, the LED1 blinks.
Keeping the loop that print data on the serial port, such as:

IWDG_Reset example test:
Feed dog count: 1
Feed dog count: 2
Feed dog count: 3
Feed dog count: 4
Feed dog count: 5
Feed dog count: 6
Feed dog count: 7
Feed dog count: 8
Feed dog count: 9
Feed dog count: 10
