# SPI_FALSH_DMA_Polling

## Introduction

This demo shows the SPI's communication, using DMA polling mode to transfer data.

## Note

Please select SW2 as On-board resources on MB-025 board before verification.

## Run

1. Run the program and print the data through serial port as follows：

   sprintf ok

   Start SPI test 

   SPI2 test

   rx[0]=0x0

   rx[1]=0x2

   rx[2]=0x4

   rx[3]=0x6

   rx[4]=0x8

   rx[5]=0xa

   rx[6]=0xc

   rx[7]=0xe

   rx[8]=0x10

   rx[9]=0x12

   SPI WR 25xx Successful

   SPI2 test over

   
   
   
   
   
   
   
