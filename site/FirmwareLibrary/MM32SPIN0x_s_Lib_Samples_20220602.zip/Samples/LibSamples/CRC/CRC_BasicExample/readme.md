# CRC_BasicExample

## Introduction

This demo shows the  CRC's basic feature.

Performs data CRC check and compares the check result with the check result of the CRC check tool.

## Run

If LED1, LED2, LED3, and LED4 all blink, it means that the CRC check is correct.
If only LED1 and LED2 blink, it means that the CRC check is error.
