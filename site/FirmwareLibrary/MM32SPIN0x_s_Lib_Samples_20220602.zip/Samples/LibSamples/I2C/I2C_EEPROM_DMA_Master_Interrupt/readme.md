# I2C_EEPROM_DMA_Master_Interrupt

## Introduction

This demo shows the  I2C's master dma interrupt feature.
Configure DMA channel for data transmission.

## Run

Run the program and print 16 sent data through the serial port with baud rate of 115200，which is：

TX data 0 is: a
TX data 1 is: b
TX data 2 is: c
TX data 3 is: d
TX data 4 is: e
TX data 5 is: f
TX data 6 is: 1
TX data 7 is: 2
TX data 8 is: 3
TX data 9 is: 4
TX data10 is: 5
TX data11 is: 6
TX data12 is: 7
TX data13 is: 8
TX data14 is: 9
TX data15 is: 9

Start receive data...
RX data 0 is: a
RX data 1 is: b
RX data 2 is: c
RX data 3 is: d
RX data 4 is: e
RX data 5 is: f
RX data 6 is: 1
RX data 7 is: 2
RX data 8 is: 3
RX data 9 is: 4
RX data10 is: 5
RX data11 is: 6
RX data12 is: 7
RX data13 is: 8
RX data14 is: 9
RX data15 is: 9
I2C_EEPROM_DMA_Master_Interrupt test over.
