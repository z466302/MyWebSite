# PWR_Sleep_WFI_Wakeup

## Introduction

This demo shows the  PWR's sleep and wakeup function.
Configure EXTI_0 (PA0) rising edge to wake up Sleep mode, enter sleep mode by using wait for interrupt(WFI) instruction.

## Run

1. Enter sleep mode, LED1, LED2, LED3, LED4 keep on.
2. Press the K1(PA0 pin) button to wake up from sleep mode, and LED1, LED2, LED3, LED4 blink continuously. 