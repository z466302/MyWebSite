# PWR_PVD_Interrupt

## Introduction

This demo verifies the  PWR's PVD feature.
The interrupt mode is used in the program, and the PVD threshold is selected as 3.0V.   When VDD drops below the PVD threshold or when VDD rises above the PVD threshold, a PVD interrupt will be generated.

## Run

LED2 flashes quickly 5 times first, and then changes to slow flashing.

