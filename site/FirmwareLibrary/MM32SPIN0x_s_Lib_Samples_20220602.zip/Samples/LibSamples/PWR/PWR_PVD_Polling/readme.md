# PWR_PVD_Polling

## Introduction

This demo shows the  PWR's PVD polling.
After running the program, observe the LED state to judge whether the current voltage is greater than  PVD threshold.

## Run

1. if the current voltage is greater than PVD threshold, LED2 level inversion 10 times and then LED1, LED2, LED3, LED4 keep on.
2. if the current voltage is less than PVD threshold, LED2 level inversion 10 times first and then the LED2 blinks，LED1, LED3 and LED4 keep on.
