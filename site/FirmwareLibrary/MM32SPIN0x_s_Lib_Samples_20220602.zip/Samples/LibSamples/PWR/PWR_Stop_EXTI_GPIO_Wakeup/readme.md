# PWR_Stop_EXTI_GPIO

## Introduction

This demo shows the  PWR's EXTI weak up STOP mode feature.
Configure K1(PA0), K3(PB10), K4(PB11) to wake up the STOP mode.  Enter the STOP mode by using the WFI instruction.  

## Run

Enter STOP mode, the LED1~LED4 lights up and LED1 level is inverted 10 times.

Press K1, K3 or K4 to wakeup from STOP mode, LED3 flashes.