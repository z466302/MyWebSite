# PWR_Standby_IWDG_Wakeup

## Introduction

This demo shows PWR's IWDG wakeup feature.

## Run

If IWDG reset, LED1 blinks, if IWDG not reset LED2 blinks.