# CAN_Tx

## Introduction

This demo shows the  CAN's send data feature.

## Note

1. Connect the CAN test tool, CAN_L--CAN_L，CAN_H--CAN_H.
## Run

USB_CAN_DebugTool receive data is as follows(Baud rate:500K，StandardFrame)：

0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08
