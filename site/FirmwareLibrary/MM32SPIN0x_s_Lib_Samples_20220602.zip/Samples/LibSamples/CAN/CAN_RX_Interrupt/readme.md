# CAN_Rx_interrupt

## Introduction

This demo shows the  CAN's Rx data feature by interruption method.

## Note

- Connect the CAN test tool, CAN_L--CAN_L，CAN_H--CAN_H.

## Run

USB_CAN_DebugTool sends "00 11 22 33 44 55 66 77" to the MCU tby CAN, and the MCU prints out "CANID: 0x172 Data:011223344556677" through UART

(CAN:  ID: 0X172 , Baud rate:500K，Standard frame)

## Important infomation

The CAN module maybe receive the other CANID except 0X172, more detail need to refer the User Manual.
