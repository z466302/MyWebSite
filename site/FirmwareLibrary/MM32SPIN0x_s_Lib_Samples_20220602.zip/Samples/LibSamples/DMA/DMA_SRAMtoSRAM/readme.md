# DMA_SRAMtoSRAM

## Introduction

This demo shows the  DMA's memory to memory transmit function.
Configure the DMA memory to memory mode to transmit data . Memory data width and peripheral data width are 8 bit, 16 bit and 32 bit respectively.

## Run

1. If the data transmission is successful, the LED1、LED2、LED3 and LED4 blink.
