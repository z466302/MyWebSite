# BKP_Tamper

## Introduction

This demo shows MCU's BKP(backup register) feature.

Whether the function is normal is indicated by the on and off of LED1 and LED2.

## Run

Observe the on and off of LED1 and LED2 to judge whether the function is normal:
If LED2 is on, it means that the BKP data is read and written normally;
If LED1 is on, it means that the BKP data is read and written abnormal.
