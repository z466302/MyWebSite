# RCC_MCO

## Introduction

This demo shows the  RCC's clock output feature.
Configure PA8 multiplexed as MCO pin in the program to output the LSI.

## Preparation Work

1. Connect the logic analyzer to test the output of PA8,

## Run

The MCO(PA8) output  frequence  is about 40kHz.
