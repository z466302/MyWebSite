# ADC_Interrupt

## Introduction

This demo shows the  ADC's basic analog-to-digital conversion function of interrupt feature. 

## Note

1.Connect PA1 to VCC or GND.

## Run

Connect PA1 (ADC_Channel_1) to VCC on the board, and the value of ADCVolatge is printed by serial port. Such as: 

ADC1_CH_1=3.297582V

ADC1_CH_1=3.297582V

......

Connect PA1 (ADC_Channel_1) to GND on the board, and the value of ADCVolatge is printed by serial port. Such as: 

ADC1_CH_1=0.000000V

ADC1_CH_1=0.000000V

........
