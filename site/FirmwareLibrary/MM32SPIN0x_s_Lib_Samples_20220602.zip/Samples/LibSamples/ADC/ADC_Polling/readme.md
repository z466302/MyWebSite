# ADC_Polling

## Introduction

This demo shows the  ADC feature of MCU using polling method.

Using the Polling method to detect the voltage value from PA1.

## Run

Adjusting RV1(connected PA1), the serial port outputs the corresponding voltage value. Such as:

ADC1_CH_1=0.178901V
ADC1_CH_1=1.214432V
ADC1_CH_1=1.542418V
ADC1_CH_1=1.640733V
ADC1_CH_1=1.705202V
