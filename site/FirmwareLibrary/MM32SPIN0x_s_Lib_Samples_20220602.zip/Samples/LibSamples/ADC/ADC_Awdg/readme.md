# ADC_AWDG

## Introduction

This demo shows the  ADC's analog watchdog feature.
Configure the upper and lower limits of analog watchdog in the program, and use analog watchdog interrupt. 

## Run

1. Connect PA1 to GND or not connect any voltage signal, see LED1 is off.
2. Connect PA1 to VDD on the board and see  LED1 is on.
