# ADC_DMA_Polling

## Introduction

This demo shows the  ADC's DMA feature using the polling method.

## Run

Connect PA1 (ADC_Channel_1) to VCC on the board, and the value of ADCVolatge is printed by serial port. Such as:

ADC1_CH_1=3.29758239V

ADC1_CH_1=3.29758239V

ADC1_CH_1=3.29758239V
