# GPIO_Key

## Introduction

This demo shows the  GPIO's Key feature.
Configure the corresponding GPIO pin to make the corresponding LED level reverse after pressing the key.

## Note

K1->PB1,   K2->PB2,   K3->PB10,   K4->PB11.

## Run

Press K1, and the level of LED1 is reversed.

Press K2, and the level of LED2 is reversed.

Press K3, and the level of LED3 is reversed.

Press K4, and the level of LED4 is reversed.
