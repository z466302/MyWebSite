# GPIO_Toggle

## Introduction

This demo shows  the  GPIO's toggle feature.
Control LED1~LED4 to blink at 1000ms interval.

## Note

LED1->PA15,   LED2->PB3,   LED3->PB4,   LED4->PB5.

## Run

LED1, LED2, LED3, LED4  blink.
