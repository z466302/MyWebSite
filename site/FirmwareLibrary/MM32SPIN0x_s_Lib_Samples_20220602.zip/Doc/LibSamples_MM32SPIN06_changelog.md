# LibSamples_MM32SPIN06 change log

## V1.2.0-2022/05/20

- Partial modification
    Device layer: change hal_ver.c version number and updated date
- Application layer
    LibSamples: update and move some samples
    RegSamples: move all reg samples
- Reconstructed initial version.
- Add readme.md file for each example project.
- Support Keil toolchain.
- support IAR toolchain.
