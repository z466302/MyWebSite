/***********************************************************************************************************************
    @file    lpuart_polling.c
    @author  FAE Team
    @date    22-Mar-2023
    @brief   THIS FILE PROVIDES ALL THE SYSTEM FUNCTIONS.
  **********************************************************************************************************************
    @attention

    <h2><center>&copy; Copyright(c) <2023> <MindMotion></center></h2>

      Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
    following conditions are met:
    1. Redistributions of source code must retain the above copyright notice,
       this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
       the following disclaimer in the documentation and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or
       promote products derived from this software without specific prior written permission.

      THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *********************************************************************************************************************/

/* Define to prevent recursive inclusion */
#define _LPUART_POLLING_C_

/* Files include */
#include <stdio.h>
#include "platform.h"
#include "lpuart_polling.h"

/**
  * @addtogroup MM32L0020_LibSamples
  * @{
  */

/**
  * @addtogroup LPUART
  * @{
  */

/**
  * @addtogroup LPUART_Polling
  * @{
  */

/* Private typedef ****************************************************************************************************/

/* Private define *****************************************************************************************************/

/* Private macro ******************************************************************************************************/

/* Private variables **************************************************************************************************/

/* Private functions **************************************************************************************************/

/***********************************************************************************************************************
  * @brief
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void LPUART_AutoCalcBR_MCTL(uint32_t Clock, uint16_t Baudrate, uint16_t *BR, uint16_t *MCTL)
{
    uint8_t  i = 0;
    uint32_t S[13], N[13];
    uint32_t MIN = 0, MODU = 0;

    printf("\r\nFuclk : %dHz", Clock);
    printf("\r\nFbsp  : %dbps", Baudrate);

    for (i = 0; i < 13; i++)
    {
        S[i] = 0;
        N[i] = 0;
    }

    for (i = 1; i < 13; i++)
    {
        S[i] = (uint16_t)(((float)Clock / (float)Baudrate * i * 10 + 5) / 10);
        N[i] = S[i] - S[i - 1];
    }

    MIN = N[1];

    for (i = 2; i < 13; i++)
    {
        if (MIN > N[i])
        {
            MIN = N[i];
        }
    }

    *BR = MIN - 1;

    for (i = 1; i < 13; i++)
    {
        if (N[i] - *BR - 1)
        {
            MODU |= (1 << i);
        }
    }

    *MCTL = MODU >> 1;
}

/***********************************************************************************************************************
  * @brief
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
uint8_t LPUART_Configure(void)
{
    GPIO_InitTypeDef   GPIO_InitStruct;
    LPUART_InitTypeDef LPUART_InitStruct;
    RCC_ClocksTypeDef  RCC_Clocks;

    uint16_t BR = 0, MCTL = 0;

    RCC_GetClocksFreq(&RCC_Clocks);

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource1, GPIO_AF_2);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource13, GPIO_AF_2);

    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Pin   = GPIO_Pin_1;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_High;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Pin   = GPIO_Pin_13;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_LPUART, ENABLE);

    LPUART_StructInit(&LPUART_InitStruct);
    LPUART_InitStruct.LPUART_BaudRate       = LPUART_Baudrate_9600;
    LPUART_InitStruct.LPUART_WordLength     = LPUART_WordLength_8b;
    LPUART_InitStruct.LPUART_StopBits       = LPUART_StopBits_1;
    LPUART_InitStruct.LPUART_Parity         = LPUART_Parity_No;
    LPUART_InitStruct.LPUART_ClockSource    = 0;
    LPUART_InitStruct.LPUART_MODU           = 0x952;
    LPUART_InitStruct.LPUART_NEDET          = LPUART_NegativeDectect_Use;
    LPUART_InitStruct.LPUART_RecvEvent      = LPUART_RecvEvent_Start_Bit;

    if ((0 == LPUART_InitStruct.LPUART_ClockSource) || (1 == LPUART_InitStruct.LPUART_ClockSource)) /* LSI:32.768kHz */
    {
        RCC_LSICmd(ENABLE);

        while (RESET == RCC_GetFlagStatus(RCC_FLAG_LSIRDY))
        {
            __NOP();
        }

        switch (LPUART_InitStruct.LPUART_BaudRate)
        {
            case LPUART_Baudrate_9600:
                LPUART_InitStruct.LPUART_MODU = 0x952;
                break;

            case LPUART_Baudrate_4800:
                LPUART_InitStruct.LPUART_MODU = 0xEFB;
                break;

            case LPUART_Baudrate_2400:
                LPUART_InitStruct.LPUART_MODU = 0x6DB;
                break;

            case LPUART_Baudrate_1200:
                LPUART_InitStruct.LPUART_MODU = 0x492;
                break;

            case LPUART_Baudrate_600:
                LPUART_InitStruct.LPUART_MODU = 0x6D6;
                break;

            case LPUART_Baudrate_300:
                LPUART_InitStruct.LPUART_MODU = 0x842;
                break;

            default:
                printf("\r\nBaudrate not supported!!!");
                return (0);
        }
    }
    else if (2 == LPUART_InitStruct.LPUART_ClockSource)
    {
        LPUART_AutoCalcBR_MCTL(RCC_Clocks.PCLK1_Frequency, 9600, &BR, &MCTL);
    }
    else
    {
    }

    printf("\r\n-->BR   = 0x%x", BR);
    printf("\r\n-->MCTL = 0x%x", MCTL);

    LPUART_Init(LPUART1, &LPUART_InitStruct);

    if (2 == LPUART_InitStruct.LPUART_ClockSource)
    {
        if ((0 == BR) || (1 == BR) || (2 == BR))
        {
            printf("\r\nBaudrate not supported!!!");
            return (0);
        }
        else
        {
            MODIFY_REG(LPUART1->LPUBAUD, LPUART_LPUBAUD_BR, BR << LPUART_LPUBAUD_BR_Pos);
            MODIFY_REG(LPUART1->LPUBAUD, LPUART_LPUBAUD_BAUD_Msk, 0x01U << LPUART_LPUBAUD_BAUD_Pos);
            MODIFY_REG(LPUART1->LPUBAUD, LPUART_LPUBAUD_BREN, 0x01U << LPUART_LPUBAUD_BREN_Pos);
            MODIFY_REG(LPUART1->MODU, LPUART_MODU_MCTL_Msk, MCTL << LPUART_MODU_MCTL_Pos);
        }
    }

    LPUART_Cmd(LPUART1, ENABLE);

    return (1);
}

/***********************************************************************************************************************
  * @brief
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void LPUART_Polling_Sample(void)
{
    uint8_t i = 0;

    printf("\r\nTest %s", __FUNCTION__);

    for(i = 0; i < 10; i++)
    {
        printf(".");
        PLATFORM_DelayMS(200);
    }

    if (1 == LPUART_Configure())
    {
        printf("\r\nSend byte to LPUART");

        while (1)
        {
            if (SET == LPUART_GetFlagStatus(LPUART1, LPUART_LPUSTA_RXF))
            {
                LPUART_SendData(LPUART1, LPUART_ReceiveData(LPUART1));

                while (RESET == LPUART_GetFlagStatus(LPUART1, LPUART_LPUSTA_TXE))
                {
                }
            }
        }
    }
    else
    {
        while (1)
        {
            PLATFORM_LED_Toggle(LED1);
            PLATFORM_DelayMS(100);
        }
    }
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/********************************************** (C) Copyright MindMotion **********************************************/

