# DIV_Operation

## Introduction

This demo shows the  DIV's division calculation feature.
Configure the divisor and dividend in the program, the divisor starts to increase from 2, the dividend is the dataBuf[] array in the program, and the serial port outputs the division result.

## Run

If the hardware division result is different from the software division result, the serial port outputs ERROR;  if the number of errors is greater than 2, the serial port outputs' Error count is:' and the number of errors.

If the calculation result of hardware division is the same as that of software division, the serial port outputs' HardWare Divider Success.' 'The result of division is: ' and outputs the calculation result.

