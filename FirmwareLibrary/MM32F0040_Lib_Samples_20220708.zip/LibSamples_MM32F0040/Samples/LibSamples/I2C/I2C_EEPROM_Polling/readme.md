# I2C_EEPROM_Polling

## Introduction

This demo shows the  I2C's polling feature.

Configure polling mode to write and read data.

## Run

Run the program and print 8 sent data through the serial port with baud rate of 115200，which is：

TX data0 is  : aa

TX data1 is  : bb

TX data2 is  : cc

TX data3 is  : dd

TX data4 is  : ee

TX data5 is  : ff

TX data6 is  : 11

TX data7 is  : 22

Print 8 receive data through the serial port with baud rate of 115200, which is ：

RX data0 is  : aa

RX data1 is  : bb

RX data2 is  : cc

RX data3 is  : dd

RX data4 is  : ee

RX data5 is  : ff

RX data6 is  : 11

RX data7 is  : 22

i2c1 polling test over
