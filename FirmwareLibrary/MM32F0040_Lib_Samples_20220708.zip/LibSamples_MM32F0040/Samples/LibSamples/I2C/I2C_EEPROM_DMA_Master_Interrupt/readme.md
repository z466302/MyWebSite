# I2C_EEPROM_DMA_Master_Interrupt

## Introduction

This demo shows the  I2C's master dma interrupt feature.
Configure DMA channel for data transmission. The program is initialized to standard speed mode.

This example does not support fast speed mode for the time being.

## Run

Run the program and print 8 sent data through the serial port with baud rate of 115200，which is：

TX data0 is  : a 

TX data1 is  : b 

TX data2 is  : c

TX data3 is  : d 

TX data4 is  : e 

TX data5 is  : f

TX data6 is  : 1

TX data7 is  : 2

Run the program and print 8 receive data through the serial port with baud rate of 115200，which is

RX data0 is  : a 

RX data1 is  : b 

RX data2 is  : c

RX data3 is  : d 

RX data4 is  : e 

RX data5 is  : f

RX data6 is  : 1

RX data7 is  : 2

i2c1 dma test over

