# I2C_GPIO_SIM_EEPROM

## Introduction

This demo shows the I2C's use GPIO to simulate I2C for data transmission.
Write data into buffer0[128] of EEPROM when the host is writing; Read data from EEPROM buffer0[128] during read operation; Compare whether the written and read data are consistent.

## Run

If the send data and received data are all the same, the LED2 level is reversed every 1000ms.

If the send data is not match with receive data, the LED1 level is reversed every 100ms.

