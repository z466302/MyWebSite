# FLASH_Program

## Introduction

This demo shows the  FLASH's programming operation feature.
Release FLASH protection, half-word programming，write data to the target address in half-word units.

## Run

If the FLASH programming is successful, the LED1、LED2、LED3、LED4 level will be inverted once every 1000 ms.

If the FLASH programming is failds, the LED1、LED2 level will be inverted once every 100 ms, LED3、LED4 will not turn on.

