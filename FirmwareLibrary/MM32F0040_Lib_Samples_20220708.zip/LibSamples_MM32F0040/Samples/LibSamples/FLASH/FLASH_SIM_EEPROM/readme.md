# FLASH_SIM_EEPROM

## Introduction

This demo shows the  FLASH's analog eeprom feature.
Using FLASH to simulate EEPROM for data transmission, first write to the same address, then read. This program indicates whether the simulated EEPROM data transmission is successful or not by turning on or off the LED.

## Run

If LED1, LED2,LED3, LED4 light once and then LED2 light, LED1, LED3 and LED4 not light, the FLASH simulation EEPROM is successful, and the data of write operation is the same as that of read operation.

If LED1, LED2,LED3, LED4 light once and then LED1 light, LED2, LED3 and LED4 not light, the read-write data of FLASH analog EEPROM does not match.

