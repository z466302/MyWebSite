# FLASH_SetReadProtect

## Introduction

This demo shows the  FLASH's set read protect feature.

Verify the success or failure of read protection by the blinking phenomenon of LED.

Need to manually erase FLASH after downloading and running the program.

## Run

If the FLASH read protect is successful, the LED3、LED4 level will be inverted every 100 ms.

If the FLASH read protect is faild, the LED1、LED2、LED3、LED4 level will be inverted every 1000 ms.

