# GPIO_Toggle

## Introduction

This demo shows  the  GPIO's toggle feature.
Control LED1~LED4 to blink at 1000ms interval.

## Note

LED1->PA4,   LED2->PA5,   LED3->PB6,   LED4->PD4.

## Run

LED1, LED2, LED3, LED4  blink at 1000ms interval.
