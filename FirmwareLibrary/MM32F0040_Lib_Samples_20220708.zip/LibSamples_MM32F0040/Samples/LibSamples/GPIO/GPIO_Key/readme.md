# GPIO_Key

## Introduction

This demo shows the  GPIO's Key feature.
Configure the corresponding GPIO pin to make the corresponding LED level reverse after pressing the key.

## Note

K2->PB7, K2->PA5.

## Run

Press K2, and the level of LED2 is reversed.
