# RCC_MCO

## Introduction

This demo shows the  RCC's clock output.
The current system clock is 72MHZ, configure the prescaler coefficient of the MCO clock source to divide the clock source by 8.

## Note 

1. Connect the oscilloscope to monitor the output signal of PB1.

## Run

The PWM is about 9.01MHZ observed from the oscilloscope of PB1, that is, the system clock is 72MHZ.  

