# CRC_BasicExample

## Introduction

This demo shows the  CRC's detecting errors in data transmission process feature.
Perform cyclic redundancy check on the data, compare the results with those obtained by cyclic redundancy check tool, and observe the correctness and errors. Accuracy is displayed by LED flashing.

## Run

If CRC calculate don't have error number, LED1、LED2、LED3、LED4 level inversion.

If CRC calculate have error number,LED1、LED2 level inversion.

