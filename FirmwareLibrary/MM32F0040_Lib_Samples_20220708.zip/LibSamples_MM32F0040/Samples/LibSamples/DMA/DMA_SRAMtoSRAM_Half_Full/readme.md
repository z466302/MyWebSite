# DMA_SRAMtoSRAM_Half_Full

## Introduction

This demo shows the  DMA's memory to memory half full feature.

Configures the DMA and test DMA move 64 8bits data for A address to B address.

## Run

If the data transmission is successful, the LED1、LED2、LED3、LED4 level will be inverted once every second.
