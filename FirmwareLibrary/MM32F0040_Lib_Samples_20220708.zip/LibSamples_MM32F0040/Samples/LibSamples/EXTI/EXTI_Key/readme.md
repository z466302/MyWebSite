# EXTI_Key

## Introduction

This demo shows the  EXTI's use external interrupts to control 1 buttons feature.
When the button is pressed, the corresponding LED level inversion. 

## Note

K1->PA0, LED1->PA4.

## Run

When the button is pressed, the corresponding LED level inversion. 

K1 -> LED1 level inversion

