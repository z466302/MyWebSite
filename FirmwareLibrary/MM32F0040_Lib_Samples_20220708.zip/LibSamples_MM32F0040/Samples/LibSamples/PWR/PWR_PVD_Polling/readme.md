# PWR_PVD_Polling

## Introduction

This demo verifies the  PWR's PVD polling feature.
After running the program, observe the LED state to judge whether the current voltage is greater than or less than PVD threshold.

## Run

If the current voltage is greater than PVD threshold, LED1 level inversion 10 times than LED1, LED2, LED3, LED4 keep light.

If the current voltage is less than PVD threshold, LED1 level inversion 10 times first and than LED2 keep level inversion.

