# PWR_Sleep_WFI_Wakeup

## Introduction

This demo shows the  PWR's sleep and wakeup feature.
Configure EXTI_0 (PA0) rising edge to wake up Sleep mode, enter sleep mode by using wait for interrupt(WFI) instruction.

## Note

Press K1 button corresponding to PA0 pin after the program runs.

## Run

Enter sleep mode, LED1, LED2, LED3, LED4 lights up.

Press the K1(PA0 pin) button to wake up from sleep mode, and LED1, LED2, LED3, LED4 continuous electrical level inversion.
