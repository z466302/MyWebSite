# PWR_PVD_Interrupt

## Introduction

This demo verifies the  PWR's PVD feature.
The interrupt mode is used in the program, and the PVD threshold is selected as 3.0V.   When VDD drops below the PVD threshold or when VDD rises above the PVD threshold, a PVD interrupt will be generated.

## Run

The LED1 level is inverted 10 times, and then the LED2 flashes continuously.

