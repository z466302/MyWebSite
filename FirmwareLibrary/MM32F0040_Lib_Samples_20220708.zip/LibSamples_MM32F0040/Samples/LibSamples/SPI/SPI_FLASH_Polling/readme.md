# SPI_FALSH_Polling

## Introduction

This demo shows the SPI's communication,use polling method to complete data transmission.

## Run

Run the program and print the data through serial port as follows：

SPI2 test

temp[0] = 186

temp[1] = 96

temp[2] = 20

rx[0]=0x0

rx[1]=0x1

rx[2]=0x2

rx[3]=0x3

rx[4]=0x4

rx[5]=0x5

rx[6]=0x6

rx[7]=0x7

rx[8]=0x8

rx[9]=0x9

SPI2 test over







