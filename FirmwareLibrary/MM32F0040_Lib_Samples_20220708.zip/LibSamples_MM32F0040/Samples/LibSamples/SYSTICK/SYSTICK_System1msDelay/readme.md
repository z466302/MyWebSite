# SYSTICK_System1msDelay

## Introduction

This demo shows the  SYSTICK's timer feature.
Configure 4 LED blink at intervals of 1 second. 

## Run

LED1, LED2, LED3, LED4 blink at intervals of 1 second. 

