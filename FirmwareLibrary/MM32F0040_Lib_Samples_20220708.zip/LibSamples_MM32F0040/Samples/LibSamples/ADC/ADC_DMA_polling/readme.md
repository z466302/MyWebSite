# ADC_DMA_Polling

## Introduction

This demo shows the  ADC's DMA feature use the polling method feature. 

##Note

​	1.Connect PA0(ADC_Channel_0) to VCC or GND.

## Run

Connect PA0(ADC_Channel_0) to VCC on the board, and the value of ADCVolatge is printed by serial port. Such as: 

ADC1_CH_0=3.292747V

ADC1_CH_0=3.292747V

ADC1_CH_0=3.293553V
