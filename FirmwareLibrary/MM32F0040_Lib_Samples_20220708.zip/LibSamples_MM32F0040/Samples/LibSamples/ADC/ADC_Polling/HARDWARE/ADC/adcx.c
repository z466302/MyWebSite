////////////////////////////////////////////////////////////////////////////////
/// @file    adcx.c
/// @author  AE TEAM
/// @brief   Output received data.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////
// Define to prevent recursive inclusion
#define _ADCX_C_

// Files includes



#include "main.h"
#include "delay.h"
#include "adcx.h"

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Hardware_Abstract_Layer
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup ADCX
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup ADC_Exported_Functions
/// @{



////////////////////////////////////////////////////////////////////////////////
/// @brief  Setup the ADC port clock
/// @param  ADCn : Select ADC port.
/// @param  state : Enable or disable the ADC clock.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCxClockSet(ADC_TypeDef* ADCn, FunctionalState state)
{
    if(ADCn == ADC1) {
        RCC_APB2PeriphClockCmd(RCC_APB2ENR_ADC1, ENABLE);                    //Enable ADC clock
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Setup the GPIO port clock
/// @note   This function should affected by chip version.
/// @param  GPIOn : Select GPIO port.
/// @param  state : Enable or disable the GPIO clock.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
static void GPIOxClockSet(GPIO_TypeDef* GPIOn, FunctionalState state)
{
    if(GPIOn == GPIOA) {
        RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOA, state);
    }
    else if(GPIOn == GPIOB) {
        RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOB, state);
    }
    else if(GPIOn == GPIOC) {
        RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOC, state);
    }
    else if(GPIOn == GPIOD) {
        RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOD, state);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  ADC Pin Configuration.
/// @param  None
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCxAssignPin(GPIO_TypeDef* GPIOn, u16 pin)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_StructInit(&GPIO_InitStruct);
    GPIOxClockSet(GPIOn, ENABLE);
    GPIO_InitStruct.GPIO_Pin  =  pin;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;                           //Output speed
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AIN;                               //GPIO mode
    GPIO_Init(GPIOn, &GPIO_InitStruct);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Enable the selected ADC channel
/// @param  ADCn: where n can be 1, 2 to select the ADC peripheral.
/// @param  channel: the ADC channel to configure.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCxChannelEnable(ADC_TypeDef* ADCn, ADCCHANNEL_TypeDef channel)
{
    ADCn->CHSR &= ~(1 << channel);
    ADCn->CHSR |=  (1 << channel);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Disable the selected ADC channel
/// @param  ADCn: where n can be 1, 2 to select the ADC peripheral.
/// @param  channel: the ADC channel to configure.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCxChannelDisable(ADC_TypeDef* ADCn, ADCCHANNEL_TypeDef channel)
{
    ADCn->CHSR &= ~(1 << channel);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  ADC1 pin Configuration with parameter.
/// @param  None
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADC1PinConfigWithParameter(void)
{
    ADCxAssignPin(GPIOA, GPIO_Pin_0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  ADC1 channel Configuration with parameter.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADC1ChannelConfigWithParameter(void)
{
    ADC_TypeDef* ADCn;
    ADCn = ADC1;
    ADCxChannelEnable(ADCn, ADC_Channel_0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  ADC1 basic configuration with parameter.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADC1BasicConfigWithParameter(void)
{
    ADC_InitTypeDef  ADC_InitStruct;
    ADC_TypeDef* ADCn;
    ADCn = ADC1;
    ADC_StructInit(&ADC_InitStruct);

    ADCxClockSet(ADCn, ENABLE);                                                //Enable ADC clock

    ADC_InitStruct.ADC_Resolution = ADC_Resolution_12b;                       //ADC resolution select 12bit
    ADC_InitStruct.ADC_PRESCARE = ADC_PCLK2_PRESCARE_16;                      //ADC prescale factor
    ADC_InitStruct.ADC_Mode = ADC_Mode_Scan;                                  //Set ADC mode to continuous conversion mode
    ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;                       //Data right-justified
    ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;        //The external trigger source of the ADC is T1_CC1

    ADC_Init(ADCn, &ADC_InitStruct);
    ADC_RegularChannelConfig(ADCn, ADC_Channel_0, 0, ADC_Samctl_240_5);
    ADC_Cmd(ADCn, ENABLE);                                                      //Enable ADC
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  ADC1 get single channel conversion value.
/// @param  None
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
u16 GetSingleChannelValue(void)
{
    u16 puiADData;
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);                                     //Software start conversion
    while(ADC_GetFlagStatus(ADC1, ADC_IT_EOC) == 0);
    ADC_ClearFlag(ADC1, ADC_IT_EOC);
    puiADData = ADC_GetConversionValue(ADC1);
    return puiADData;
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is getting the average of ADC
/// @note   None.
/// @param  times.
/// @retval average.
////////////////////////////////////////////////////////////////////////////////
u16 GetAdcAverage(u8 times)
{
    u32 temp_val = 0;
    u8 t;
    u8 delay;
    for(t = 0; t < times; t++) {
        temp_val += GetSingleChannelValue();
        for(delay = 0; delay < 100; delay++);
    }
    return temp_val / times;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  ADC1 single channel initialization.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADC1SingleChannelInit(void)
{
    printf("ADC1_CH0 test\r\n");
    ADC1BasicConfigWithParameter();
    ADC1ChannelConfigWithParameter();
    ADC1PinConfigWithParameter();
}


/// @}


/// @}

/// @}


