# ADC_Polling

## Introduction

This demo shows the  ADC's basic analog-to-digital conversion feature. 

## Note

1.Connect PA0 to VCC or GND.

## Run

Connect PA0 (ADC_Channel_0) to VCC on the board, and the value of ADCVolatge is printed by serial port. Such as: 

The ADC average is 4095V

The ADC average is 4095V

......

Connect PA0 (ADC_Channel_0) to GND on the board, and the value of ADCVolatge is printed by serial port. Such as: 

The ADC average is 0V

The ADC average is 0V

........
