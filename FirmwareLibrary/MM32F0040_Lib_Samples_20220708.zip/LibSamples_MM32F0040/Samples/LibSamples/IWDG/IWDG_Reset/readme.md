# IWDG_Reset

## Introduction

This demo shows the  IWDG's reset feature.
If the dog is continuously fed, the program does not enter the reset; If the dog feeding is blocked, IWDG is reset. Watchdog counter reload value is 0xff.

## Note

There is an ''Write_Iwdg_RL()'' in the while loop of the main function, and the program keeps feeding the dog. If want IWDG reset, mask ''Write_Iwdg_RL()''.

## Run

The program keeps feeding the dog, IWDG does not reset, and LED2 light down.

Mask the dog feeding function 'Write_Iwdg_RL()', the program resets IWDG, and LED1 continuously reverses the electrical level.

