# COMP_Polling

## Introduction

This demo shows the  COMP's Polling feature.

Compare the positive input with the negative input. If the positive input is greater than the negative input, the ucA value is 1. If the positive input is smaller than the negative input, the ucA value is 0.

## Note

The PD6 pin is used as an inverting input.  
The PA4 pin is used as a positive phase input.  

## Run

Connect PA4 to GND and connect PD6 to VCC, the non-inverting input is smaller than the inverting input. The serial port with baud rate of 115200 prints out 'the comparator result is: 0'.

Connect PA4 to VCC and connect PD6 to GND, the non-inverting input is greater than the inverting input. The serial port with baud rate of 115200 prints out 'the comparator result is: 1'.

