# LibSamples_MM32F0040



## Introduction

LibSamples_MM32F0040 is to provide the software package for developing MindMotion MM32F0040 MCU. The software package includes the device's header file, linker file, startup code, peripherals driver and examples projects. 

## User guide

### ToolChains

- Keil MDK for Arm, v5.37.0.0, with pack MindMotion.MM32F0040_DFP.0.0.3.
- IAR IDE for Arm, v9.10.2, with zip file MM32_IAR_EWARM_pack_MM32F0040.zip.


### Hardware board

- Mini-F0040(MM32F0040B1T)

### Source files

| directory                                | description              |
| ---------------------------------------- | ------------------------ |
| `\Device\MM32F0040`                      | NPI enablement files.    |
| `\Device\MM32F0040\HAL_Lib`              | Drivers.                 |
| `\Samples\LibSamples\<MODULE>\<Example>` | Driver example projects. |

### Example projects

 - ADC
   - ADC_DMA_Interrupt
   - ADC_DMA_polling
   - ADC_Interrupt
   - ADC_Polling
 - COMP
   - COMP_Polling
 - CRC
   - CRC_BasicExample
 - DIV
   - DIV_Operation
 - DMA
   - DMA_SRAMtoSRAM
   - DMA_SRAMtoSRAM_Half_Full
 - EXTI
   - EXTI_Key
 - FLASH
   - FLASH_Program
   - FLASH_SetReadProtect
   - FLASH_SIM_EEPROM
 - GPIO
   - GPIO_Key
   - GPIO_Toggle
 - I2C
   - I2C_EEPROM_DMA_Master_Interrupt
   - I2C_EEPROM_DMA_polling
   - I2C_EEPROM_Master_Interrupt
   - I2C_EEPROM_Polling
   - I2C_GPIO_SIM_EEPROM
 - IWDG
   - IWDG_Reset
 - PWR
   - PWR_PVD_Interruput
   - PWR_PVD_Polling
   - PWR_Sleep_WFI_Wakeup
   - PWR_Standby_IWDG_Wakeup
   - PWR_Stop_EXTI_GPIO_Wakeup
 - RCC
   - RCC_MCO
 - SPI
   - SPI_FLASH_DMA_Polling
   - SPI_FLASH_Interrupt
   - SPI_FLASH_Polling
 - SYSTICK
   - SYSTICK_System1msDelay
 - TIM
   - TIM1_6Steps
   - TIM1_BasicExample
   - TIM1_CC1_Interrupt
   - TIM1_Dma_Ccr3
   - TIM1_DMA_UPData
   - TIM1_Interrupt
   - TIM1_Monopulse
   - TIM_Sync_1Master2Slave
 - UART
   - UART_Polling
   - UART_Print_Polling
 - WWDG
   - WWDG_Reset

## Know issues

- The MiniBoard (MM32F0040B1T) does not include the USB-to-serial port module, need prepare USB TO TTL.
