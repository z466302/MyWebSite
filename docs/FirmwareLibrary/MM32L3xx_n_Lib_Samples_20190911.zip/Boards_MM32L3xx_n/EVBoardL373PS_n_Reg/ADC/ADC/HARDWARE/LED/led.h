#ifndef __LED_H
#define __LED_H
#include "sys.h"


//LED�˿ڶ���
#define LED2 PAout(8)	// PA8
#define LED1 PCout(13)	// PC13	

void LED_Init(void);	//��ʼ��
#endif

















