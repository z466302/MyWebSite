#ifndef		__USB_APP_H_
#define		__USB_APP_H_
void USB_GPIO(void);
void usb_test(void);
void keyBoard_ctrl(char spcKey, char nomKey0, char nomKey1, char nomKey2,
                   char nomKey3, char nomKey4, char nomKey5) ;
#endif

