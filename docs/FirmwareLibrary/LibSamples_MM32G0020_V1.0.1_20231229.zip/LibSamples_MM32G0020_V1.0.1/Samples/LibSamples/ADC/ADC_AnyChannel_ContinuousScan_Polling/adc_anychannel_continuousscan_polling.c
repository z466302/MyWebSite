/***********************************************************************************************************************
    @file    adc_anychannel_continuousscan_polling.c
    @author  FAE Team
    @date    30-Nov-2023
    @brief   THIS FILE PROVIDES ALL THE SYSTEM FUNCTIONS.
  **********************************************************************************************************************
    @attention

    <h2><center>&copy; Copyright(c) <2023> <MindMotion></center></h2>

      Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
    following conditions are met:
    1. Redistributions of source code must retain the above copyright notice,
       this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
       the following disclaimer in the documentation and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or
       promote products derived from this software without specific prior written permission.

      THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *********************************************************************************************************************/

/* Define to prevent recursive inclusion */
#define _ADC_ANYCHANNEL_CONTINUOUSSCAN_POLLING_C_

/* Files include */
#include <stdio.h>
#include "platform.h"
#include "adc_anychannel_continuousscan_polling.h"

/**
  * @addtogroup MM32G0020_LibSamples
  * @{
  */

/**
  * @addtogroup ADC
  * @{
  */

/**
  * @addtogroup ADC_AnyChannel_ContinuousScan_Polling
  * @{
  */

/* Private typedef ****************************************************************************************************/

/* Private define *****************************************************************************************************/

/* Private macro ******************************************************************************************************/

/* Private variables **************************************************************************************************/

/* Private functions **************************************************************************************************/

/***********************************************************************************************************************
  * @brief
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void ADC_Configure(void)
{
    ADC_InitTypeDef  ADC_InitStruct;
    GPIO_InitTypeDef GPIO_InitStruct;

    RCC_APB1PeriphClockCmd(RCC_APB1PERIPH_ADC1, ENABLE);

    ADC_StructInit(&ADC_InitStruct);
    ADC_InitStruct.ADC_Resolution = ADC_RESOLUTION_12B;
    ADC_InitStruct.ADC_Prescaler  = ADC_PRESCALER_16;
    ADC_InitStruct.ADC_Mode       = ADC_MODE_CONTINUE;
    ADC_InitStruct.ADC_DataAlign  = ADC_DATAALIGN_RIGHT;
    ADC_Init(ADC1, &ADC_InitStruct);

    ADC_SampleTimeConfig(ADC1, ADC_CHANNEL_0, ADC_SAMPLETIME_240_5);
    ADC_SampleTimeConfig(ADC1, ADC_CHANNEL_4, ADC_SAMPLETIME_240_5);
    ADC_SampleTimeConfig(ADC1, ADC_CHANNEL_7, ADC_SAMPLETIME_240_5);

    ADC_AnyChannelNumCfg(ADC1, 2);
    ADC_AnyChannelSelect(ADC1, ADC_ANYCHANNEL_0, ADC_CHANNEL_0);
    ADC_AnyChannelSelect(ADC1, ADC_ANYCHANNEL_1, ADC_CHANNEL_4);
    ADC_AnyChannelSelect(ADC1, ADC_ANYCHANNEL_2, ADC_CHANNEL_7);
    ADC_AnyChannelCmd(ADC1, ENABLE);

    RCC_AHBPeriphClockCmd(RCC_AHBPERIPH_GPIOA, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPERIPH_GPIOB, ENABLE);

    /* PA11(RV1) PB1(RV2) PA7(RV3) */
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Pin   = GPIO_PIN_11 | GPIO_PIN_7;
    GPIO_InitStruct.GPIO_Speed = GPIO_SPEED_HIGH;
    GPIO_InitStruct.GPIO_Mode  = GPIO_MODE_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Pin   = GPIO_PIN_1;
    GPIO_InitStruct.GPIO_Speed = GPIO_SPEED_HIGH;
    GPIO_InitStruct.GPIO_Mode  = GPIO_MODE_AIN;
    GPIO_Init(GPIOB, &GPIO_InitStruct);

    ADC_Cmd(ADC1, ENABLE);
}

/***********************************************************************************************************************
  * @brief
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void ADC_AnyChannel_ContinuousScan_Polling_Sample(void)
{
    float Voltage[3];

    printf("\r\nTest %s", __FUNCTION__);

    ADC_Configure();

    ADC_SoftwareStartConvCmd(ADC1, ENABLE);

    while (1)
    {
        while (RESET == ADC_GetFlagStatus(ADC1, ADC_FLAG_EOS))
        {
        }

        ADC_ClearFlag(ADC1, ADC_FLAG_EOS);

        Voltage[0] = (float)ADC_GetChannelConvertedValue(ADC1, ADC_CHANNEL_0) * (float)3.3 / (float)4096.0;
        Voltage[1] = (float)ADC_GetChannelConvertedValue(ADC1, ADC_CHANNEL_4) * (float)3.3 / (float)4096.0;
        Voltage[2] = (float)ADC_GetChannelConvertedValue(ADC1, ADC_CHANNEL_7) * (float)3.3 / (float)4096.0;

        printf("\r\nPA1 Voltage = %0.2f  \tPA4 Voltage = %0.2f  \tPA5 Voltage = %0.2f", Voltage[0], Voltage[1], Voltage[2]);
    }
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/********************************************** (C) Copyright MindMotion **********************************************/

