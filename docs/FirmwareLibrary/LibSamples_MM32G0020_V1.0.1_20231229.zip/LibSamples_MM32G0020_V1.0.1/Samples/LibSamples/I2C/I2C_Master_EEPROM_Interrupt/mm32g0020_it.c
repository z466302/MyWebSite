/***********************************************************************************************************************
    @file    mm32g0020_it.c
    @author  FAE Team
    @date    30-Nov-2023
    @brief   THIS FILE PROVIDES ALL THE SYSTEM FUNCTIONS.
  **********************************************************************************************************************
    @attention

    <h2><center>&copy; Copyright(c) <2023> <MindMotion></center></h2>

      Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
    following conditions are met:
    1. Redistributions of source code must retain the above copyright notice,
       this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
       the following disclaimer in the documentation and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or
       promote products derived from this software without specific prior written permission.

      THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *********************************************************************************************************************/

/* Define to prevent recursive inclusion */
#define _MM32G0020_IT_C_

/* Files include */
#include "platform.h"
#include "i2c_master_eeprom_interrupt.h"
#include "mm32g0020_it.h"

/**
  * @addtogroup MM32G0020_LibSamples
  * @{
  */

/**
  * @addtogroup I2C
  * @{
  */

/**
  * @addtogroup I2C_Master_EEPROM_Interrupt
  * @{
  */

/* Private typedef ****************************************************************************************************/

/* Private define *****************************************************************************************************/

/* Private macro ******************************************************************************************************/

/* Private variables **************************************************************************************************/

/* Private functions **************************************************************************************************/

/***********************************************************************************************************************
  * @brief  This function handles Non maskable interrupt
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void NMI_Handler(void)
{
    while (1)
    {
    }
}

/***********************************************************************************************************************
  * @brief  This function handles Hard fault interrupt
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void HardFault_Handler(void)
{
    while (1)
    {
    }
}

/***********************************************************************************************************************
  * @brief  This function handles Memory management fault
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void MemManage_Handler(void)
{
    while (1)
    {
    }
}

/***********************************************************************************************************************
  * @brief  This function handles Pre-fetch fault, memory access fault
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void BusFault_Handler(void)
{
    while (1)
    {
    }
}

/***********************************************************************************************************************
  * @brief  This function handles Undefined instruction or illegal state
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void UsageFault_Handler(void)
{
    while (1)
    {
    }
}

/***********************************************************************************************************************
  * @brief  This function handles System service call via SWI instruction
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void SVCall_Handler(void)
{
}

/***********************************************************************************************************************
  * @brief  This function handles Debug monitor
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void DebugMon_Handler(void)
{
}

/***********************************************************************************************************************
  * @brief  This function handles Pendable request for system service
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void PendSV_Handler(void)
{
}

/***********************************************************************************************************************
  * @brief  This function handles System tick timer
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void SysTick_Handler(void)
{
    if (0 != PLATFORM_DelayTick)
    {
        PLATFORM_DelayTick--;
    }
}

/***********************************************************************************************************************
  * @brief  This function handles I2C1 Handler
  * @note   none
  * @param  none
  * @retval none
  *********************************************************************************************************************/
void I2C1_IRQHandler(void)
{
    uint8_t Data = 0;

    if (SET == I2C_GetITStatus(I2C1, I2C_IT_RX_FULL))
    {
        I2C_ClearITPendingBit(I2C1, I2C_IT_RX_FULL);

        Data = I2C_ReceiveData(I2C1);

        if (0 == I2C_RxStruct.CompleteFlag)
        {
            I2C_RxStruct.Buffer[I2C_RxStruct.CurrentCount++] = Data;

            if (I2C_RxStruct.CurrentCount == I2C_RxStruct.Length)
            {
                I2C_RxStruct.CompleteFlag = 1;

                I2C_ITConfig(I2C1, I2C_IT_RX_FULL, DISABLE);
            }
            else
            {
                I2C_ReadCmd(I2C1);
            }
        }
    }

    if (SET == I2C_GetITStatus(I2C1, I2C_IT_TX_EMPTY))
    {
        I2C_ClearITPendingBit(I2C1, I2C_IT_TX_EMPTY);

        if (0 == I2C_TxStruct.CompleteFlag)
        {
            I2C_SendData(I2C1, I2C_TxStruct.Buffer[I2C_TxStruct.CurrentCount++]);

            if (I2C_TxStruct.CurrentCount == I2C_TxStruct.Length)
            {
                I2C_TxStruct.CompleteFlag = 1;

                I2C_ITConfig(I2C1, I2C_IT_TX_EMPTY, DISABLE);
            }
        }
    }
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/********************************************** (C) Copyright MindMotion **********************************************/

