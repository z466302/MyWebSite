# LibSamples_MiniBoard_F0020

## Introduction

LibSamples_MiniBoard_F0020 is to provide the software package for developing MindMotion MM32F0020 MCU. The software package includes the device's header file, linker file, startup code, peripherals drivers and examples projects.

## User guide

### ToolChains

- Keil MDK for Arm, v5.34.0.0, with MindMotion.MM32F0020_DFP.pack.
- IAR Embedded Workench for Arm, v8.10.5521 with MM32_IAR_EWARM_pack_MM32F0020.zip.

### Hardware board

- Mini-F0020 (MM32F0020B1T)

### Source files

| directory                                | description              |
| ---------------------------------------- | ------------------------ |
| `\Device\MM32F0020`                      | NPI enablement files.    |
| `\Device\MM32F0020\HAL_Lib`              | Drivers.                 |
| `\Samples\LibSamples\<MODULE>\<Example>` | Driver example projects. |

### Example projects

- ADC
  - ADC_Awdg
  - ADC_Interrupt
  - ADC_Polling
- CRC
  - CRC_BasicExample
- EXTI
  - EXTI_Key
- FLASH
  - FLASH_Program
  - FLASH_SetReadProtect
  - FLASH_SIM_EEPROM
- GPIO
  - GPIO_Toggle
- I2C
  - I2C_EEPROM_Polling
  - I2C_GPIO_SIM_EEPROM
- IWDG
  - IWDG_Reset
- PWR
  - PWR_PVD_Interruput
  - PWR_PVD_Polling
  - PWR_Sleep_WFI_Wakeup
  - PWR_Standby_IWDG_Wakeup
  - PWR_Stop_Iwdg_Wakeup
- SPI
  - SPI_FLASH_Interrupt
  - SPI_FLASH_Polling
  - SPI_GPIO_SIM_ExSpiFlash
- SYSTICK
  - SYSTICK_System1msDelay
- TIM
  - TIM1_6Steps
  - TIM1_BasicExample
  - TIM1_CC1_Interrupt
  - TIM1_Interrupt
  - TIM1_Monopulse
  - TIM1_PWM_Shift
  - TIM3_PWM_Output
- UART
  - UART_Polling
  - UART_Print_Polling

## Known issues

- IAR toolchain

    Please do install the pack `Tools/MM32_IAR_EWARM_pack_MM32F0020.zip` when using the J-Link to download the firmware.

    
