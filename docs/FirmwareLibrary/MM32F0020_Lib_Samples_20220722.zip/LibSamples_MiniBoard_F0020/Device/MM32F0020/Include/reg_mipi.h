#if defined(__MM0Y1)
#include "MIPI\reg_wwdg_M0Y1.h"
#endif
