# GPIO_Toggle

## Introduction

This demo shows the  GPIO's toggle feature.
Control LD2~LD5 to blink at 1000ms interval. 

## Run

 LD2, LD3, LD4, LD5 blink at 1000ms interval.
