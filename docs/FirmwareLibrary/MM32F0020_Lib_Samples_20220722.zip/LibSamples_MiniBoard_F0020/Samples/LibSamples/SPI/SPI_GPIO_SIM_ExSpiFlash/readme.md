# SPI_GPIO_SIM_ExSpiFlash

## Introduction

This demo shows the SPI's communication by software simulate method.
Read and write instructions are sent to Flash through SPI, write and read data to the same address of Flash .
Compare whether the elements in the array gRxData and the array gTxData[] are equal, judge whether the analog SPI communication is normal.  If they are not equal, the onboard LED will light up, otherwise it will be off.  

## Run

1. Run the program and LD2, LD3, LD4, LD5 are off.