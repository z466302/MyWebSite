# SPI_FALSH_Polling

## Introduction

This demo shows the SPI's communication, using polling method to complete data transmission.
SCK -> PA8, MISO -> PA1, MOSI -> PA9, NSS -> PA15.

## Run

Run the program and print the data through serial port as follows：

SPI1 test
rx[0]=0x0
rx[1]=0x1
rx[2]=0x2
rx[3]=0x3
rx[4]=0x4
rx[5]=0x5
rx[6]=0x6
rx[7]=0x7
SPI_FALSH_Polling test is over
