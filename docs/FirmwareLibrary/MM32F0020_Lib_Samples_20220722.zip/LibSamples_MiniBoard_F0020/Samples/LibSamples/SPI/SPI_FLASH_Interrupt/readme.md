# SPI_FALSH_Interrupt

## Introduction

This demo shows the SPI's communication, using polling method to complete data transmission.
Using Flash module, SCK -> PA8, MISO -> PA1, MOSI -> PA9, NSS -> PA15. 

## Run

Run the program and print the data through serial port as follows：

SPI1 test
rx[0]=0x2
rx[1]=0x3
rx[2]=0x4
rx[3]=0x5
rx[4]=0x6
rx[5]=0x7
rx[6]=0x8
rx[7]=0x9
SPI_FALSH_Interrupt test is over

   

   

   

   
