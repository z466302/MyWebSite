# ADC_AWDG

## Introduction

This demo shows the  ADC's analog watchdog feature.
Configure the upper and lower limits of analog watchdog in the program, and use analog watchdog interrupt. 

## Run

1. Adjusting RV1(connected PA7) to GND or not connect any voltage signal, see LD2 is off.
2. Adjusting RV1(connected PA7) to VDD on the board and see  LD2 is on.
