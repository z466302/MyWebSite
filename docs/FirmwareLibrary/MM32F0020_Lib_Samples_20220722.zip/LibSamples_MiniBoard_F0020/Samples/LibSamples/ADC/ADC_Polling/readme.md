# ADC_Polling

## Introduction

This demo shows the  ADC feature of MM32F0020 using polling method.

Using the Polling method to detect the voltage value from PA2.

## Run

Adjusting RV2(connected PA2), the serial port outputs the corresponding voltage value. Such as:

ADC_Polling example test
ADC1_CH_5=1.923590V
ADC1_CH_5=1.944542V
ADC1_CH_5=1.946154V
ADC1_CH_5=1.947766V
ADC1_CH_5=1.921978V
