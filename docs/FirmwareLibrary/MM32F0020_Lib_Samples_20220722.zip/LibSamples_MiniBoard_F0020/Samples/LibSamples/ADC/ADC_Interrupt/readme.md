# ADC_Interrupt

## Introduction

This demo shows the  ADC's interrupt feature.

Using the interrupt feature of ADC to detect the voltage value from PA2.

## Run

Adjusting RV2(connected PA2), the serial port outputs the corresponding voltage value. Such as:

ADC_Interrupt example test
ADC1_CH_5=1.839780V
ADC1_CH_5=1.838974V
ADC1_CH_5=1.839780V
ADC1_CH_5=1.838974V
ADC1_CH_5=1.838974V
ADC1_CH_5=1.839780V
