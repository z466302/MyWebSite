# UART_Polling

## Introduction

This demo shows the MCU's  UART feature using polling method. 
After the RXD of UART receives the data, it sends the same data through TXD .

## Run

Send '1234567890' to MCU by serial debuggin assistant XCOM, and XCOM receive '1234567890'.

Shown as follows:  

→◇1234567890  
←◆1234567890

