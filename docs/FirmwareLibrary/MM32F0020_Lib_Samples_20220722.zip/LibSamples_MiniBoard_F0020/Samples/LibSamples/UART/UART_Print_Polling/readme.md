# UART_Print_Polling

## Introduction

This demo verifies the UART's print feature by using plliong meathod. 
After the RXD of UART receives the data, it sends the same data through TXD .

## Run

Send '1234567890' to MCU by serial debuggin assistant XCOM, and XCOM receive '1234567890', and meanwhile, LD2, LD3 and LED4 shining.

Shown as follows:  

→◇1234567890  
←◆1234567890

