# TIM1_PWM_Shift

## Introduction

This demo shows the TIM1's PWM phase shift feature. 

## Note

1. Connect the logic analyzer to monitor the output of PA6, PA8 and PA9. 
## Run

The value of ARR configured in the program is 1000, that is, a cycle count value is 1000.
PA6(TIM1_CH3), PA8(TIM1_CH2), PA9(TIM1_CH1) to output PWM with a duty cycle of 70%. 
The OC1 rollover point to 300.
The OC2 rollover point to 250.
The OC3 rollover point to 350.
