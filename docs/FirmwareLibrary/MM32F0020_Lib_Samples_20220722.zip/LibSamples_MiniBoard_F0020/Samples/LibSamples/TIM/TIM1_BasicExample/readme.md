# TIM1_BasicExample

## Introduction

This demo shows the TIM1's basic feature. 
Configure the TIM1 clock frequency so that the LD2~LD5 state toggle every 100ms 

## Run

Every 100ms, the LD2~LD5 state toggle.
