# TIM3_PWM_Output

## Introduction

This demo shows the  TIM3's PWM output feature.

## Note

1. Connect the logic analyzer to test the output of PA11

## Run

TIM3_CH1(PA11) outputs PWM at an interval of 40ms. 
The PWM frequency is 720KHZ, and the duty cycle is 50%. 