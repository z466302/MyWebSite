# TIM1_CC1_Interrupt

## Introduction

This demo shows the  TIM1's capture/compare interrupt feature.
Configure the TIM1 period as 100ms, output compare mode, update interrupt control LD2, LD3 blink, capture/compare interrupt control LD4, LD5 blink.

## Run

LD2, LD3, LD4 and LD5 blink