# TIM1_Interrupt

## Introduction

This demo shows the TIM1's interrupt feature. 
Configure the TIM1 interrupt to make the LD2~LD5 state toggle every 100ms   

## Run

The LD2~LD5 state toggle every 100ms.
