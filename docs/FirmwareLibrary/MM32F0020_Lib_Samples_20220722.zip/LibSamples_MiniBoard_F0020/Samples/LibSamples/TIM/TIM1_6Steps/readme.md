# TIM1_6Steps

## Introduction

This demo shows the  TIM1's 6-step commutation feature.

### Note

1. Connect the logic analyzer to test the output of PA0, PA2, PA6, PA7, PA9, PA11.

## Run

Observe the output waveform, The six-step PWM output sequence is:  
(CC2N,CC1)-->(CC2N,CC3)-->(CC3,CC1N)-->(CC2,CC1N)-->(CC3N,CC2)-->(CC3N,CC1)