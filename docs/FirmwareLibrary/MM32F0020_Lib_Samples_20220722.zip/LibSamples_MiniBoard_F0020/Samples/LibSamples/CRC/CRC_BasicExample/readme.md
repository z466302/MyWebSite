# CRC_BasicExample

## Introduction

This demo shows the  CRC's basic feature.

Performs data CRC check and compares the check result with the check result of the CRC check tool.

## Run

If LD2, LD3, LD4 and LD5 all flash, it means that the CRC check is correct.  
If only LD2 and LD3 all flash, it means that the CRC check is error.  
