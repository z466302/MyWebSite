# I2C_GPIO_SIM_EEPROM

## Introduction

This demo shows the  GPIO simulate I2C feature.

Configure I2C polling mode to write and read data.

## Run

Run the program, LD3 blink.