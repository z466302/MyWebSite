# IWDG_Reset

## Introduction

This demo shows the IWDOG's reset feature. 
After ten feed dog operations, reset the system, and print data on the serial port.

## Run

Keep the loop that  print data on the serial port, such as:

The System Start Up
Feed dog count: 1
Feed dog count: 2
Feed dog count: 3
Feed dog count: 4
Feed dog count: 5
Feed dog count: 6
Feed dog count: 7
Feed dog count: 8
Feed dog count: 9
Feed dog count: 10
The System Start Up
IWDGRST
Feed dog count: 1
Feed dog count: 2
Feed dog count: 3
Feed dog count: 4
Feed dog count: 5
Feed dog count: 6
Feed dog count: 7
Feed dog count: 8
Feed dog count: 9
Feed dog count: 10
