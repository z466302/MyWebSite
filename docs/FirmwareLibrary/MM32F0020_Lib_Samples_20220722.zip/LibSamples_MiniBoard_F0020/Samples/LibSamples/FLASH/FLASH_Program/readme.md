# FLASH_Program

## Introduction

This demo shows the  MCU's FLASH feature.

If the programming is successful, make the LD3 blink , otherwise make the LD2 blink.

## Run

The LD3 blink, which means that the FLASH programming is successful.
