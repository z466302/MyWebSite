# SYSTICK_System1msDelay

## Introduction

This demo shows the SysTick's 1ms delay feature. 
Configure the SysTick handler, and use SysTick interrupt. 
Make the status of the LD2~LD5 change every 1000ms.

## Run

The status of the LD2~LD5 change every 1000ms
