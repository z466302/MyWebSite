# PWR_Standby_IWDG_Wakeup

## Introduction

This demo shows the PWR's IWDG wakeup function in standy mode.

The reset state of IWDG is displayed by the LED on and off. If the IWDG is reset, it will exit the standby mode, restart the program, later the program will enter the IWDG reset again, and the cycle will continue.

## Run

1. Power on again after power off, LD2 is always on after slow flashing, enter Standby mode and refresh the display.
2. LD3 blink quickly, indicating that the IWDG is reset, the Standby mode has been exited at this time, and the system is restarted.