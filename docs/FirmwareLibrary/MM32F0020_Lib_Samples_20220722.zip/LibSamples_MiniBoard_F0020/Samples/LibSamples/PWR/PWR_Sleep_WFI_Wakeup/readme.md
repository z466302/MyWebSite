# PWR_Sleep_WFI_Wakeup

## Introduction

This demo shows the PWR's interrupt wakeup function in sleep mode.

## Run

The external interrupt wakes up the MCU, and the MCU can be woken up by pressing K1(PA0) to make LD2~LD5 blink.

