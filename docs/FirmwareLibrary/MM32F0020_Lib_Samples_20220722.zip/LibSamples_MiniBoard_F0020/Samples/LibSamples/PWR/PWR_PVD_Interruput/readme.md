# PWR_PVD_Interrupt

## Introduction

This demo shows the  PWR's PVD Interrupt feature.
After running the program, watch the LD3 state to judge whether the current voltage is greater than or less than PVD threshold.
If current voltage is greater than configured PVD threshold, the LD3 changes to low frequency blink.

## Run
After running the program, the LD3 blink frequency changes from high to low.