# PWR_PVD_Polling

## Introduction

This demo shows the  PWR's PVD polling.
After running the program, observe the LD3 state to judge whether the current voltage is greater than or less than PVD threshold.

## Run

After runing the program, the LD3 changed from blink status to keep on, indicates the current voltage is greater than PVD threshold.