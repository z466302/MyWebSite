# PWR_Stop_IWDG_Wakeup

## Introduction

This demo shows the PWR's IWDG  interrupt wake up function in stop mode.

The IWDG  interrupt wake up MCU from stop mode, then continue to run the program, making LED light blinks.

## Run

1. When the program is running,  waiting LD2, LD4 and LD5  are off, LD3 blinks continuously , indicating that IWDG interrupt wake up MCU from stop mode.
