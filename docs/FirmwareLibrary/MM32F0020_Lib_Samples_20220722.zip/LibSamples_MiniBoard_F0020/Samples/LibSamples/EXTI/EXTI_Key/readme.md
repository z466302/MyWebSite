# EXTI_KEY

## Introduction

 This demo shows the  EXTI's external interruption.

Completed an external interrupt feature triggered by four keys.

## Run

When the  K1,  K2 or K4 is pressed, the LD2, LD3,  or LD5 on or off.
