# LibSamples_MiniBoard_F0020 change log



## v1.0 2022-06-16

- Reconstructed initial version.
- Add readme.md file for each example project.
- Support Keil toolchain.
- Support IAR toolchain.
